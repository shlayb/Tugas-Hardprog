#include <iostream>
#include <cmath>
using namespace std;

struct koordinat{
    float latitude;
    float longitude;
};

int main(){
  koordinat point[2];
  float jarak;
  for(int i=0; i<2; i++){
    system("cls");
    cout << "Masukkan latitude: ";
    cin >> point[i].latitude;
    cout << "Masukkan longitude: ";
    cin >> point[i].longitude;
  }

// menghitung jarak
  for(int i = 1; i<2;i++){
    jarak  += sqrt(pow((point[i].latitude - point[i-1].latitude),2) + pow((point[i].longitude - point[i-1].longitude),2));
  }
  
  cout << "Jarak 2 titik :" << jarak;
  return 0;
}